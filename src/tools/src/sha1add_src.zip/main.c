/*
# _____     ___ ____     ___ ____
#  ____|   |    ____|   |        | |____|
# |     ___|   |     ___|    ____| |    \    PSPDEV Open Source Project.
#-----------------------------------------------------------------------
#
# 2008-01-31 - Richard Ainger <raing3@gmail.com>
#	- 1st release
#
# $Id: unpack-pbp.c 2379 2008-04-08 21:18:58Z jim $
*/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <stdio.h>
#include <stdlib.h>

#ifdef HAVE_MALLOC_H
#include <malloc.h>
#endif

#ifdef WORDS_BIGENDIAN

// Swap the bytes of an int for big-endian machines
static int swap_int(int n)
{
   return ((n >> 24) & 0xff) | ((n >> 8) & 0xff00) | ((n << 8) & 0xff0000) | ((n << 24) & 0xff000000);
}

#endif

// Maximum size of read buffer
int maxbuffer = 16*1024*1024;

int main(int argc, char *argv[]) {
   FILE *infile;
   FILE *outfile;
   char *buffer, *hval;
   int loop0;
   int total_size;

   buffer = malloc(maxbuffer);
   hval = malloc(20);
   
   // Check for the correct number of arguments
   if (argc != 3) {
      printf("USAGE: %s <inpbpname> <outpbpname>\n", argv[0]);
      return -1;
   }
   
   // Open the specified PBP
   infile = fopen(argv[1], "rb");
   if (infile == NULL) {
      printf("ERROR: Could not open the input file. (%s)\n", argv[1]);
      return -1;
   }
   
   // Get the size of the input PBP
   fseek(infile, 0, SEEK_END);
   total_size = ftell(infile);
   fseek(infile, 0, SEEK_SET);
   if (total_size < 0) {
      printf("ERROR: Could not get the input file size.\n");
      return -1;
   }

   if (total_size > maxbuffer) {
	   printf("ERROR: Max buffer size is too small for specified EBOOT.\n");
	   return -1;
   }
   
   // Read in the input EBOOT
   if (fread(buffer, total_size, 1, infile) < 0) {
      printf("ERROR: Could not read the input file.\n");
      return -1;
   }
   
#ifdef WORDS_BIGENDIAN
   
   // Swap the bytes of the offsets for big-endian machines
   for (loop0 = 0; loop0 < 8; loop0++) {
      header.offset[loop0] = swap_int(header.offset[loop0]);
   }
   
#endif
  
   // Close the PBP
   if (fclose(infile) < 0) {
      printf("ERROR: Could not close the input file.\n");
      return -1;
   }

   // Open the specified output PBP
   outfile = fopen(argv[2], "wb");
   if (infile == NULL) {
      printf("ERROR: Could not open the output file. (%s)\n", argv[2]);
	  return -1;
   }
   
   // Write the original PBP data
   if (fwrite(buffer, total_size, 1, outfile) < 0) {
	   printf("ERROR: Could not write output EBOOT data.\n");
	   return -1;
   }

   sha1(hval, buffer, total_size);
   
   if (fwrite(hval, 20, 1, outfile) < 0) {
	   printf("ERROR: Could not write output hash data.\n");
	   return -1;
   }

   // Close the PBP
   if (fclose(infile) < 0) {
      printf("ERROR: Could not close the input file.\n");
      return -1;
   }
   
   // Exit successful
   return 0;
} 

